import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { nav, site } from '../data/portfolio'
import useActiveSection from '../hooks/useActiveSection'

const IDS = nav.map((n) => n.id)

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const active = useActiveSection(IDS)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [open])

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled || open
          ? 'border-b border-ink-500/60 bg-ink-800/90 py-3 shadow-[0_10px_40px_-20px_rgba(0,0,0,0.8)] backdrop-blur-xl'
          : 'border-b border-transparent bg-transparent py-5'
      }`}
    >
      <nav
        aria-label="Primary"
        className="mx-auto flex max-w-7xl items-center justify-between px-6 md:px-10"
      >
        <a
          href="#home"
          onClick={() => setOpen(false)}
          className="group flex items-center gap-3 font-display text-lg font-bold tracking-tight"
          aria-label={`${site.brand} — back to top`}
        >
          <span className="flex h-9 w-9 items-center justify-center border border-silver/60 text-[11px] tracking-widest transition-colors group-hover:bg-fg group-hover:text-ink-900">
            {site.monogram}
          </span>
          <span className="hidden sm:inline">{site.brand}</span>
        </a>

        <ul className="hidden items-center gap-1 md:flex">
          {nav.map((item) => {
            const isActive = active === item.id
            return (
              <li key={item.id}>
                <a
                  href={`#${item.id}`}
                  aria-current={isActive ? 'page' : undefined}
                  className={`group relative block px-4 py-2 font-mono text-[11px] uppercase tracking-[0.2em] transition-colors ${
                    isActive ? 'text-hi' : 'text-sub hover:text-fg'
                  }`}
                >
                  <span className="inline-block transition-transform duration-300 group-hover:-translate-y-0.5">
                    {item.label}
                  </span>
                  {isActive ? (
                    <motion.span
                      layoutId="nav-indicator"
                      className="absolute inset-x-4 -bottom-0.5 h-px bg-hi"
                      transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                    />
                  ) : null}
                </a>
              </li>
            )
          })}
        </ul>

        <button
          type="button"
          className="flex h-10 w-10 items-center justify-center border border-ink-500 md:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? 'Close menu' : 'Open menu'}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </nav>

      <AnimatePresence>
        {open ? (
          <motion.div
            id="mobile-menu"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-x-0 top-[61px] h-[calc(100dvh-61px)] bg-ink-900 px-6 pt-8 md:hidden"
          >
            <ul className="flex flex-col">
              {nav.map((item, i) => (
                <motion.li
                  key={item.id}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i }}
                  className="border-b border-ink-500/50"
                >
                  <a
                    href={`#${item.id}`}
                    onClick={() => setOpen(false)}
                    className={`flex items-baseline justify-between py-5 font-display text-3xl font-semibold ${
                      active === item.id ? 'text-hi' : 'text-sub'
                    }`}
                  >
                    {item.label}
                    <span className="font-mono text-xs text-mute">0{i + 1}</span>
                  </a>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  )
}
