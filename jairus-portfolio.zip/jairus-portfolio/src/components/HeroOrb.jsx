import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'

/**
 * Interactive monochrome 3D object: a brushed-metal sphere inside a wireframe
 * icosahedron and a thin orbital ring, surrounded by a particle shell.
 * It reacts to the pointer, pauses when off screen or when the tab is hidden,
 * respects prefers-reduced-motion, and cleans up all GPU resources on unmount.
 */
export default function HeroOrb() {
  const mountRef = useRef(null)

  useEffect(() => {
    const mount = mountRef.current
    if (!mount) return undefined

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    let renderer
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' })
    } catch {
      return undefined // WebGL unavailable: the CSS glow behind the canvas remains
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.toneMapping = THREE.ACESFilmicToneMapping
    renderer.toneMappingExposure = 1.05
    mount.appendChild(renderer.domElement)
    renderer.domElement.style.display = 'block'

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 100)
    camera.position.set(0, 0, 7.5)

    // Reflections give the metal something to reflect
    const pmrem = new THREE.PMREMGenerator(renderer)
    const envTexture = pmrem.fromScene(new RoomEnvironment(), 0.04).texture
    scene.environment = envTexture

    const key = new THREE.DirectionalLight(0xffffff, 2.2)
    key.position.set(4, 5, 6)
    scene.add(key)
    const rim = new THREE.DirectionalLight(0x9a9a9a, 1.2)
    rim.position.set(-5, -2, -4)
    scene.add(rim)

    const group = new THREE.Group()
    scene.add(group)

    // Metal sphere
    const sphere = new THREE.Mesh(
      new THREE.SphereGeometry(1.35, 96, 96),
      new THREE.MeshStandardMaterial({ color: 0xb4b4b4, metalness: 1, roughness: 0.22 }),
    )
    group.add(sphere)

    // Wireframe shell
    const shell = new THREE.Mesh(
      new THREE.IcosahedronGeometry(2.1, 1),
      new THREE.MeshBasicMaterial({ color: 0x8a8a8a, wireframe: true, transparent: true, opacity: 0.35 }),
    )
    group.add(shell)

    // Orbital rings
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xd4d4d4, transparent: true, opacity: 0.55 })
    const ring = new THREE.Mesh(new THREE.TorusGeometry(2.7, 0.01, 8, 200), ringMat)
    ring.rotation.x = Math.PI / 2.4
    group.add(ring)
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(3.15, 0.006, 8, 200), ringMat)
    ring2.rotation.set(Math.PI / 3, Math.PI / 5, 0)
    group.add(ring2)

    // Particle shell
    const COUNT = 700
    const positions = new Float32Array(COUNT * 3)
    for (let i = 0; i < COUNT; i += 1) {
      const r = 3.3 + Math.random() * 1.6
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta)
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta)
      positions[i * 3 + 2] = r * Math.cos(phi)
    }
    const particleGeo = new THREE.BufferGeometry()
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    const particles = new THREE.Points(
      particleGeo,
      new THREE.PointsMaterial({ color: 0xcfcfcf, size: 0.025, transparent: true, opacity: 0.7, sizeAttenuation: true }),
    )
    scene.add(particles)

    // Sizing
    const resize = () => {
      const { clientWidth: w, clientHeight: h } = mount
      if (!w || !h) return
      renderer.setSize(w, h, false)
      renderer.domElement.style.width = '100%'
      renderer.domElement.style.height = '100%'
      camera.aspect = w / h
      camera.updateProjectionMatrix()
    }
    resize()
    const resizeObserver = new ResizeObserver(resize)
    resizeObserver.observe(mount)

    // Pointer interaction (eased)
    const target = { x: 0, y: 0 }
    const current = { x: 0, y: 0 }
    const onPointerMove = (e) => {
      const rect = mount.getBoundingClientRect()
      target.x = ((e.clientX - rect.left) / rect.width - 0.5) * 2
      target.y = ((e.clientY - rect.top) / rect.height - 0.5) * 2
    }
    window.addEventListener('pointermove', onPointerMove, { passive: true })

    // Only render while visible
    let visible = true
    const io = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting
    })
    io.observe(mount)

    let raf = 0
    const clock = new THREE.Clock()
    const render = () => {
      raf = requestAnimationFrame(render)
      if (!visible || document.hidden) return
      const t = clock.getElapsedTime()

      current.x += (target.x - current.x) * 0.05
      current.y += (target.y - current.y) * 0.05

      if (!reduce) {
        sphere.rotation.y = t * 0.15
        shell.rotation.y = -t * 0.08
        shell.rotation.x = t * 0.05
        ring.rotation.z = t * 0.12
        ring2.rotation.z = -t * 0.09
        particles.rotation.y = t * 0.02
        group.position.y = Math.sin(t * 0.8) * 0.08
      }
      group.rotation.y = current.x * 0.5
      group.rotation.x = current.y * 0.3
      renderer.render(scene, camera)
    }
    render()

    return () => {
      cancelAnimationFrame(raf)
      resizeObserver.disconnect()
      io.disconnect()
      window.removeEventListener('pointermove', onPointerMove)
      scene.traverse((obj) => {
        if (obj.geometry) obj.geometry.dispose()
        if (obj.material) {
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material]
          mats.forEach((m) => m.dispose())
        }
      })
      envTexture.dispose()
      pmrem.dispose()
      renderer.dispose()
      if (renderer.domElement.parentNode === mount) mount.removeChild(renderer.domElement)
    }
  }, [])

  return <div ref={mountRef} className="h-full w-full" aria-hidden="true" />
}
