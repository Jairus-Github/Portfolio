import { useRef } from 'react'
import { motion, useReducedMotion, useScroll, useSpring } from 'framer-motion'
import { Award, Flag, GraduationCap, Rocket, Star, Wrench } from 'lucide-react'
import { timeline, timelineCategories } from '../data/portfolio'
import Reveal from './ui/Reveal'
import SectionHeading from './ui/SectionHeading'

const ICONS = {
  cap: GraduationCap,
  rocket: Rocket,
  wrench: Wrench,
  award: Award,
  flag: Flag,
  star: Star,
}

function Entry({ item, index }) {
  const cat = timelineCategories[item.category]
  const Icon = ICONS[cat?.icon] || Flag
  const left = index % 2 === 0

  return (
    <li className="relative pb-12 pl-14 last:pb-0 md:grid md:grid-cols-2 md:gap-20 md:pl-0">
      {/* Node on the line */}
      <motion.span
        aria-hidden="true"
        initial={{ scale: 0 }}
        whileInView={{ scale: 1 }}
        viewport={{ once: true, margin: '-20% 0px' }}
        transition={{ type: 'spring', stiffness: 300, damping: 18 }}
        className={`absolute left-5 top-6 z-10 flex h-9 w-9 -translate-x-1/2 items-center justify-center border md:left-1/2 ${
          item.placeholder
            ? 'border-dashed border-ink-500 bg-ink-900 text-mute'
            : 'border-silver bg-ink-800 text-hi'
        }`}
      >
        <Icon size={15} />
      </motion.span>

      <Reveal
        y={24}
        className={left ? 'md:col-start-1' : 'md:col-start-2'}
      >
        <div
          className={`relative p-6 transition-colors duration-300 ${
            item.placeholder
              ? 'border border-dashed border-ink-500 bg-transparent hover:border-silver/60'
              : 'metal-border hover:brightness-125'
          }`}
          style={{ '--surface': '#222222' }}
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="eyebrow !text-silver">{cat?.label}</span>
            {item.period ? <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-mute">{item.period}</span> : null}
          </div>
          <h3 className={`mt-4 font-display text-xl font-semibold leading-snug ${item.placeholder ? 'text-sub' : 'text-hi'}`}>
            {item.title}
          </h3>
          {item.org ? <p className="mt-1 text-sm text-silver">{item.org}</p> : null}
          {item.description ? <p className="mt-3 text-sm leading-relaxed text-sub">{item.description}</p> : null}
          {item.placeholder ? (
            <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.2em] text-mute">Editable entry</p>
          ) : null}
        </div>
      </Reveal>
    </li>
  )
}

export default function Timeline() {
  const ref = useRef(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 70%', 'end 60%'] })
  const scaleY = useSpring(scrollYProgress, { stiffness: 120, damping: 30, restDelta: 0.001 })

  return (
    <section
      id="experience"
      className="relative scroll-mt-16 overflow-hidden bg-ink-900 py-28 md:py-40"
    >
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(50% 40% at 50% 0%, rgba(110,110,110,0.2), transparent 70%)',
        }}
      />
      <div className="relative z-10 mx-auto max-w-5xl px-6 md:px-10">
        <SectionHeading number="04" eyebrow="Education & development" title="The path" outline="so far." />

        <div ref={ref} className="relative">
          {/* Base line + scroll-driven progress line */}
          <div aria-hidden="true" className="absolute bottom-0 left-5 top-0 w-px bg-ink-500/60 md:left-1/2" />
          <motion.div
            aria-hidden="true"
            style={reduce ? { scaleY: 1 } : { scaleY }}
            className="absolute bottom-0 left-5 top-0 w-px origin-top bg-gradient-to-b from-hi via-silver to-sub md:left-1/2"
          />

          <ol className="relative">
            {timeline.map((item, i) => (
              <Entry key={item.id} item={item} index={i} />
            ))}
          </ol>
        </div>
      </div>
    </section>
  )
}
