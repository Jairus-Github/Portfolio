import { Fragment } from 'react'
import { motion, useReducedMotion } from 'framer-motion'

/** Reveals text character by character. Screen readers get the full string. */
export default function RevealText({ text, className = '', delay = 0, stagger = 0.03 }) {
  const reduce = useReducedMotion()
  const words = text.split(' ')
  let index = 0

  return (
    <span className={className} aria-label={text}>
      {words.map((word, wi) => (
        <Fragment key={`${word}-${wi}`}>
          <span className="inline-block whitespace-nowrap" aria-hidden="true">
            {[...word].map((char, ci) => {
              const d = delay + index * stagger
              index += 1
              return (
                <motion.span
                  key={`${char}-${ci}`}
                  className="inline-block"
                  initial={reduce ? false : { opacity: 0, y: '60%' }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: d, ease: [0.22, 1, 0.36, 1] }}
                >
                  {char}
                </motion.span>
              )
            })}
          </span>
          {wi < words.length - 1 ? ' ' : null}
        </Fragment>
      ))}
    </span>
  )
}
