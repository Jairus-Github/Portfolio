import Reveal from './Reveal'

/**
 * Editorial section heading: mono eyebrow with number, oversized title,
 * and an optional outlined second line.
 */
export default function SectionHeading({ number, eyebrow, title, outline, tone = 'dark', className = '' }) {
  const light = tone === 'light'
  return (
    <div className={`mb-14 md:mb-20 ${className}`}>
      <Reveal>
        <p className={`eyebrow flex items-center gap-4 ${light ? '!text-ink-500' : ''}`}>
          <span className={light ? 'text-ink-900' : 'text-silver'}>{number}</span>
          <span className={`h-px w-12 ${light ? 'bg-ink-900/40' : 'bg-ink-500'}`} />
          <span>{eyebrow}</span>
        </p>
      </Reveal>
      <Reveal delay={0.08}>
        <h2
          className={`mt-6 font-display text-[clamp(2.6rem,7vw,6rem)] font-bold uppercase leading-[0.92] tracking-tight ${
            light ? 'text-ink-900' : 'text-fg'
          }`}
        >
          {title}
          {outline ? (
            <>
              <br />
              <span className={light ? 'text-outline-dark' : 'text-outline'}>{outline}</span>
            </>
          ) : null}
        </h2>
      </Reveal>
    </div>
  )
}
