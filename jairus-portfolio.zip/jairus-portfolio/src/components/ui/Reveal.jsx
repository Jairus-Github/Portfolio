import { motion, useReducedMotion } from 'framer-motion'

/** Fades and lifts its children into view the first time they scroll on screen. */
export default function Reveal({ children, delay = 0, y = 32, className = '', as = 'div' }) {
  const reduce = useReducedMotion()
  const Component = motion[as] || motion.div

  return (
    <Component
      className={className}
      initial={reduce ? false : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </Component>
  )
}
