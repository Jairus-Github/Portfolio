import { useRef } from 'react'
import { motion, useMotionValue, useReducedMotion, useSpring } from 'framer-motion'

const VARIANTS = {
  primary:
    'bg-fg text-ink-900 hover:bg-hi border border-fg shadow-[0_10px_40px_-10px_rgba(255,255,255,0.35)]',
  ghost:
    'bg-transparent text-fg border border-ink-500 hover:border-silver hover:bg-white/5 backdrop-blur',
  dark: 'bg-ink-900 text-fg border border-ink-900 hover:bg-ink-700',
}

/**
 * Button/link that gently follows the pointer ("magnetic" effect).
 * Pass `href` to render an anchor, otherwise a button is rendered.
 */
export default function MagneticButton({
  children,
  href,
  onClick,
  variant = 'primary',
  className = '',
  strength = 0.3,
  type = 'button',
  disabled = false,
  ...rest
}) {
  const ref = useRef(null)
  const reduce = useReducedMotion()
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const sx = useSpring(x, { stiffness: 220, damping: 16, mass: 0.4 })
  const sy = useSpring(y, { stiffness: 220, damping: 16, mass: 0.4 })

  const onMove = (e) => {
    if (reduce || e.pointerType === 'touch' || !ref.current) return
    const r = ref.current.getBoundingClientRect()
    x.set((e.clientX - (r.left + r.width / 2)) * strength)
    y.set((e.clientY - (r.top + r.height / 2)) * strength)
  }
  const onLeave = () => {
    x.set(0)
    y.set(0)
  }

  const classes = `inline-flex items-center justify-center gap-2 px-7 py-4 font-mono text-xs font-medium uppercase tracking-[0.2em] transition-colors duration-300 disabled:cursor-not-allowed disabled:opacity-60 ${VARIANTS[variant]} ${className}`
  const Tag = href ? motion.a : motion.button
  const props = href ? { href } : { type, disabled }

  return (
    <Tag
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      onClick={onClick}
      style={{ x: sx, y: sy }}
      whileTap={{ scale: 0.96 }}
      className={classes}
      {...props}
      {...rest}
    >
      {children}
    </Tag>
  )
}
