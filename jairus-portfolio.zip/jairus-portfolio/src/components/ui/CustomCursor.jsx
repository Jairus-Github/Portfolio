import { useEffect, useState } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'

/**
 * Dot + trailing ring cursor. Only mounts on devices with a fine pointer
 * (mouse / trackpad) and when reduced motion is not requested. The native
 * cursor stays visible, so nothing is hidden from the user.
 */
export default function CustomCursor() {
  const [enabled, setEnabled] = useState(false)
  const [hovering, setHovering] = useState(false)
  const x = useMotionValue(-100)
  const y = useMotionValue(-100)
  const rx = useSpring(x, { stiffness: 320, damping: 30, mass: 0.5 })
  const ry = useSpring(y, { stiffness: 320, damping: 30, mass: 0.5 })

  useEffect(() => {
    const fine = window.matchMedia('(pointer: fine)').matches
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (!fine || reduce) return undefined
    setEnabled(true)

    const move = (e) => {
      x.set(e.clientX)
      y.set(e.clientY)
    }
    const over = (e) => {
      const el = e.target instanceof Element ? e.target : null
      setHovering(Boolean(el && el.closest('a, button, input, textarea, label, [data-cursor]')))
    }
    window.addEventListener('pointermove', move, { passive: true })
    window.addEventListener('pointerover', over)
    return () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerover', over)
    }
  }, [x, y])

  if (!enabled) return null

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[90] hidden md:block">
      <motion.div className="absolute left-0 top-0 h-0 w-0" style={{ x, y }}>
        <div className="absolute -left-[3px] -top-[3px] h-1.5 w-1.5 rounded-full bg-white mix-blend-difference" />
      </motion.div>
      <motion.div className="absolute left-0 top-0 h-0 w-0" style={{ x: rx, y: ry }}>
        <motion.div
          className="absolute rounded-full border border-white mix-blend-difference"
          animate={{
            width: hovering ? 60 : 32,
            height: hovering ? 60 : 32,
            x: hovering ? -30 : -16,
            y: hovering ? -30 : -16,
            opacity: hovering ? 0.9 : 0.5,
          }}
          transition={{ type: 'spring', stiffness: 300, damping: 24 }}
        />
      </motion.div>
    </div>
  )
}
