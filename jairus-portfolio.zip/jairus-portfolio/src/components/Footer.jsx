import { ArrowUp } from 'lucide-react'
import { site } from '../data/portfolio'

export default function Footer() {
  return (
    <footer className="border-t border-ink-500/60 bg-ink-800">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 md:flex-row md:px-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-mute">
          © {new Date().getFullYear()} {site.name} · {site.brand}
        </p>
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-mute">
          Always learning. Always building.
        </p>
        <a
          href="#home"
          className="group flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-sub transition-colors hover:text-hi"
        >
          Back to top
          <ArrowUp size={14} className="transition-transform group-hover:-translate-y-1" aria-hidden="true" />
        </a>
      </div>
    </footer>
  )
}
