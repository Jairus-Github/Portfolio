import { motion } from 'framer-motion'
import { BookOpen, Crosshair, Lightbulb, Mountain, Puzzle, Shuffle, Sparkles } from 'lucide-react'
import { strengths } from '../data/portfolio'
import Reveal from './ui/Reveal'

const ICONS = {
  puzzle: Puzzle,
  book: BookOpen,
  shuffle: Shuffle,
  sparkles: Sparkles,
  crosshair: Crosshair,
  bulb: Lightbulb,
  mountain: Mountain,
}

function SpotlightCard({ item, index }) {
  const Icon = ICONS[item.icon] || Sparkles

  const onMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect()
    e.currentTarget.style.setProperty('--mx', `${e.clientX - rect.left}px`)
    e.currentTarget.style.setProperty('--my', `${e.clientY - rect.top}px`)
  }

  return (
    <Reveal delay={0.05 * index} className={`${item.span} flex`}>
      <motion.div
        whileHover={{ y: -8 }}
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        onPointerMove={onMove}
        className="group relative flex min-h-[15rem] w-full flex-col justify-between overflow-hidden border border-ink-500 p-7 shadow-[0_30px_60px_-30px_rgba(0,0,0,0.7)]"
        style={{ background: item.gradient }}
      >
        {/* Soft light that follows the pointer */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{
            background:
              'radial-gradient(320px circle at var(--mx,50%) var(--my,50%), rgba(255,255,255,0.16), transparent 60%)',
          }}
        />
        <div className="relative flex items-start justify-between">
          <span className="flex h-12 w-12 items-center justify-center border border-white/15 bg-black/20 text-silver backdrop-blur transition-colors duration-300 group-hover:bg-fg group-hover:text-ink-900">
            <Icon size={22} strokeWidth={1.5} aria-hidden="true" />
          </span>
          <span className="font-mono text-xs text-mute">0{index + 1}</span>
        </div>
        <div className="relative">
          <h3 className="font-display text-2xl font-semibold text-hi">{item.title}</h3>
          <p className="mt-2 max-w-sm text-sm leading-relaxed text-sub">{item.text}</p>
        </div>
      </motion.div>
    </Reveal>
  )
}

export default function Strengths() {
  return (
    <section
      id="strengths"
      aria-labelledby="strengths-title"
      className="relative overflow-hidden py-28 md:py-40"
      style={{ background: 'linear-gradient(180deg,#d4d4d4 0%,#b4b4b4 55%,#9a9a9a 100%)' }}
    >
      <div aria-hidden="true" className="grid-bg-dark absolute inset-0" />
      <div
        aria-hidden="true"
        className="absolute -top-32 left-1/2 h-96 w-[60rem] -translate-x-1/2 rounded-full bg-white/50 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6 md:px-10">
        <Reveal>
          <p className="eyebrow mb-6 flex items-center gap-4 !text-ink-500">
            <span className="text-ink-900">05</span>
            <span className="h-px w-12 bg-ink-900/40" />
            Personal strengths
          </p>
        </Reveal>
        <Reveal delay={0.08}>
          <h2
            id="strengths-title"
            className="mb-14 font-display text-[clamp(2.6rem,8vw,7rem)] font-bold uppercase leading-[0.9] tracking-tight text-ink-900 md:mb-20"
          >
            What I bring
            <br />
            <span className="text-outline-dark">to the table</span>
          </h2>
        </Reveal>

        <div className="grid gap-5 lg:grid-cols-12">
          {strengths.map((item, i) => (
            <SpotlightCard key={item.title} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
