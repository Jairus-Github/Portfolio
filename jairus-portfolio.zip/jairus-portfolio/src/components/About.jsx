import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Quote } from 'lucide-react'
import { about, site } from '../data/portfolio'
import Reveal from './ui/Reveal'
import SectionHeading from './ui/SectionHeading'
import TiltCard from './ui/TiltCard'

const TABS = ['Details', 'Philosophy']

function Portrait() {
  return (
    <TiltCard max={6} className="mx-auto w-full max-w-md" glare>
      <div className="relative">
        {/* Layered offset borders that shift on hover */}
        <div
          aria-hidden="true"
          className="absolute inset-0 translate-x-4 translate-y-4 border border-ink-500 transition-transform duration-500 group-hover:translate-x-7 group-hover:translate-y-7"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 -translate-x-3 -translate-y-3 border border-silver/30 transition-transform duration-500 group-hover:-translate-x-5 group-hover:-translate-y-5"
        />

        <div className="metal-border relative aspect-[4/5] overflow-hidden" style={{ '--surface': '#222222' }}>
          {about.photo ? (
            <img
              src={about.photo}
              alt={about.photoAlt}
              loading="lazy"
              className="h-full w-full object-cover grayscale-[0.85] transition-all duration-700 group-hover:scale-105 group-hover:grayscale-0"
            />
          ) : (
            <div
              className="relative flex h-full w-full flex-col items-center justify-center"
              style={{
                background:
                  'radial-gradient(70% 60% at 50% 30%, #4a4a4a 0%, #222222 60%, #161616 100%)',
              }}
            >
              <div aria-hidden="true" className="grid-bg absolute inset-0 opacity-70" />
              <span className="relative font-display text-[7rem] font-bold leading-none text-outline transition-all duration-500 group-hover:text-metal">
                {site.monogram}
              </span>
              <p className="relative mt-6 max-w-[16rem] text-center font-mono text-[10px] uppercase leading-relaxed tracking-[0.2em] text-mute">
                Portrait placeholder
                <br />
                Set <span className="text-sub">about.photo</span> in portfolio.js
              </p>
            </div>
          )}
          <div
            aria-hidden="true"
            className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-ink-900/80 to-transparent"
          />
          <span className="absolute bottom-4 left-4 font-mono text-[10px] uppercase tracking-[0.25em] text-silver">
            {site.location}
          </span>
        </div>
      </div>
    </TiltCard>
  )
}

function InfoPanel() {
  const [tab, setTab] = useState(0)
  const rows = [
    ['Location', site.location],
    ['Age', String(site.age)],
    ['Current focus', about.focus],
  ]

  return (
    <div className="glass mt-10 overflow-hidden">
      <div role="tablist" aria-label="Personal information" className="flex border-b border-white/10">
        {TABS.map((label, i) => (
          <button
            key={label}
            role="tab"
            type="button"
            id={`about-tab-${i}`}
            aria-selected={tab === i}
            aria-controls={`about-panel-${i}`}
            onClick={() => setTab(i)}
            className={`relative flex-1 px-4 py-3 font-mono text-[11px] uppercase tracking-[0.22em] transition-colors ${
              tab === i ? 'text-hi' : 'text-mute hover:text-sub'
            }`}
          >
            {label}
            {tab === i ? (
              <motion.span layoutId="about-tab" className="absolute inset-x-0 bottom-0 h-px bg-hi" />
            ) : null}
          </button>
        ))}
      </div>

      <div className="min-h-[9.5rem] p-6">
        <AnimatePresence mode="wait" initial={false}>
          {tab === 0 ? (
            <motion.dl
              key="details"
              role="tabpanel"
              id="about-panel-0"
              aria-labelledby="about-tab-0"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25 }}
              className="divide-y divide-white/10"
            >
              {rows.map(([k, v]) => (
                <div
                  key={k}
                  className="group flex items-baseline justify-between gap-6 py-3 transition-colors hover:bg-white/[0.03]"
                >
                  <dt className="font-mono text-[11px] uppercase tracking-[0.2em] text-mute">{k}</dt>
                  <dd className="text-right text-sm text-fg transition-transform duration-300 group-hover:-translate-x-1">
                    {v}
                  </dd>
                </div>
              ))}
            </motion.dl>
          ) : (
            <motion.figure
              key="philosophy"
              role="tabpanel"
              id="about-panel-1"
              aria-labelledby="about-tab-1"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25 }}
              className="flex h-full min-h-[7.5rem] flex-col justify-center"
            >
              <Quote size={20} className="mb-3 text-silver" aria-hidden="true" />
              <blockquote className="font-display text-2xl font-semibold leading-snug text-hi">
                {about.philosophy}
              </blockquote>
            </motion.figure>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

export default function About() {
  return (
    <section
      id="about"
      className="grain relative scroll-mt-16 overflow-hidden bg-ink-800 py-28 md:py-40"
    >
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(50% 50% at 0% 50%, rgba(90,90,90,0.22), transparent 70%), linear-gradient(180deg, rgba(17,17,17,1) 0%, rgba(25,25,25,0) 18%)',
        }}
      />
      <div className="relative z-10 mx-auto max-w-7xl px-6 md:px-10">
        <SectionHeading number="01" eyebrow="About me" title="Curious by" outline="nature." />

        <div className="grid items-center gap-16 lg:grid-cols-12 lg:gap-20">
          <Reveal className="lg:col-span-5">
            <Portrait />
          </Reveal>

          <div className="lg:col-span-7">
            <Reveal>
              <div className="space-y-6 text-lg leading-relaxed text-sub">
                {about.paragraphs.map((p, i) => (
                  <p key={i} className={i === 0 ? 'text-xl text-fg md:text-2xl md:leading-snug' : ''}>
                    {p}
                  </p>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.1}>
              <p className="mt-8 border-l border-silver/60 pl-5 font-display text-lg italic text-silver">
                {about.pullQuote}
              </p>
            </Reveal>

            <Reveal delay={0.15}>
              <InfoPanel />
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  )
}
