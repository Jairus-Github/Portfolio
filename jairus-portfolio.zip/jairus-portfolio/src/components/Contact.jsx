import { useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { AlertCircle, CheckCircle2, Info, Link2, Loader2, Mail, Send } from 'lucide-react'
import { contact } from '../data/portfolio'
import { GitHubIcon, LinkedInIcon } from './ui/icons'
import MagneticButton from './ui/MagneticButton'
import Reveal from './ui/Reveal'

const LINK_ICONS = {
  email: Mail,
  github: GitHubIcon,
  linkedin: LinkedInIcon,
  other: Link2,
}

const FIELDS = [
  { name: 'name', label: 'Name', type: 'text', autoComplete: 'name' },
  { name: 'email', label: 'Email', type: 'email', autoComplete: 'email' },
  { name: 'subject', label: 'Subject', type: 'text', autoComplete: 'off' },
  { name: 'message', label: 'Message', type: 'textarea', autoComplete: 'off' },
]

const validators = {
  name: (v) => (v.trim().length < 2 ? 'Please enter your name.' : ''),
  email: (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) ? '' : 'Please enter a valid email address.'),
  subject: (v) => (v.trim().length < 3 ? 'Please add a short subject.' : ''),
  message: (v) => (v.trim().length < 10 ? 'Your message should be at least 10 characters.' : ''),
}

const EMPTY = { name: '', email: '', subject: '', message: '' }

function validateAll(values) {
  return Object.fromEntries(Object.keys(validators).map((k) => [k, validators[k](values[k])]))
}

function ContactLink({ link }) {
  const Icon = LINK_ICONS[link.id] || Link2
  const body = (
    <>
      <span className="flex h-11 w-11 shrink-0 items-center justify-center border border-ink-500 text-silver transition-colors duration-300 group-hover:bg-fg group-hover:text-ink-900">
        <Icon size={18} />
      </span>
      <span className="min-w-0">
        <span className="block font-mono text-[10px] uppercase tracking-[0.22em] text-mute">{link.label}</span>
        <span className="block truncate text-sm text-fg">{link.value}</span>
      </span>
    </>
  )

  // Placeholder links are not clickable so visitors never land on a dead URL.
  if (link.placeholder || !link.url) {
    return (
      <li
        className="flex items-center gap-4 border border-dashed border-ink-500 p-4 opacity-70"
        title="Placeholder — update in src/data/portfolio.js"
      >
        {body}
        <span className="ml-auto hidden font-mono text-[10px] uppercase tracking-[0.2em] text-mute sm:block">
          Placeholder
        </span>
      </li>
    )
  }
  return (
    <li>
      <a
        href={link.url}
        target={link.url.startsWith('mailto:') ? undefined : '_blank'}
        rel="noopener noreferrer"
        className="group flex items-center gap-4 border border-ink-500 p-4 transition-colors duration-300 hover:border-silver hover:bg-white/[0.03]"
      >
        {body}
      </a>
    </li>
  )
}

function Field({ field, value, error, onChange, onBlur }) {
  const id = `contact-${field.name}`
  const errId = `${id}-error`
  const shared = {
    id,
    name: field.name,
    value,
    onChange,
    onBlur,
    autoComplete: field.autoComplete,
    'aria-invalid': error ? 'true' : 'false',
    'aria-describedby': error ? errId : undefined,
    className: `peer w-full border bg-ink-800 px-4 py-3.5 text-fg placeholder-transparent transition-colors focus:border-silver focus:outline-none ${
      error ? 'border-red-400/70' : 'border-ink-500'
    }`,
    placeholder: field.label,
  }

  return (
    <div className={field.type === 'textarea' ? 'sm:col-span-2' : ''}>
      <label htmlFor={id} className="mb-2 block font-mono text-[11px] uppercase tracking-[0.2em] text-sub">
        {field.label}
      </label>
      {field.type === 'textarea' ? (
        <textarea rows={6} {...shared} className={`${shared.className} resize-y`} />
      ) : (
        <input type={field.type} {...shared} />
      )}
      <AnimatePresence>
        {error ? (
          <motion.p
            id={errId}
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-2 flex items-center gap-2 text-sm text-red-300"
          >
            <AlertCircle size={14} aria-hidden="true" /> {error}
          </motion.p>
        ) : null}
      </AnimatePresence>
    </div>
  )
}

function ContactForm() {
  const formRef = useRef(null)
  const [values, setValues] = useState(EMPTY)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle') // idle | sending | success | error | unconfigured

  const handleChange = (e) => {
    const { name, value } = e.target
    setValues((v) => ({ ...v, [name]: value }))
    if (errors[name]) setErrors((er) => ({ ...er, [name]: validators[name](value) }))
    if (status !== 'idle' && status !== 'sending') setStatus('idle')
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    setErrors((er) => ({ ...er, [name]: validators[name](value) }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const nextErrors = validateAll(values)
    setErrors(nextErrors)
    const firstInvalid = Object.keys(nextErrors).find((k) => nextErrors[k])
    if (firstInvalid) {
      formRef.current?.elements[firstInvalid]?.focus()
      return
    }

    // Honeypot: real visitors never fill this hidden field.
    if (formRef.current?.elements.company?.value) {
      setStatus('success')
      return
    }

    if (!contact.formEndpoint) {
      setStatus('unconfigured')
      return
    }

    setStatus('sending')
    try {
      const res = await fetch(contact.formEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(values),
      })
      if (!res.ok) throw new Error(`Request failed with ${res.status}`)
      setStatus('success')
      setValues(EMPTY)
      setErrors({})
    } catch {
      setStatus('error')
    }
  }

  const emailLink = contact.links.find((l) => l.id === 'email')
  const emailReady = emailLink && !emailLink.placeholder

  return (
    <form
      ref={formRef}
      onSubmit={handleSubmit}
      noValidate
      aria-label="Contact form"
      className="glass grid gap-6 p-6 sm:grid-cols-2 md:p-8"
    >
      {FIELDS.map((f) => (
        <Field
          key={f.name}
          field={f}
          value={values[f.name]}
          error={errors[f.name]}
          onChange={handleChange}
          onBlur={handleBlur}
        />
      ))}

      {/* Honeypot (hidden from people and assistive tech) */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label htmlFor="contact-company">Company</label>
        <input id="contact-company" name="company" type="text" tabIndex={-1} autoComplete="off" />
      </div>

      <div className="flex flex-col gap-4 sm:col-span-2">
        <MagneticButton type="submit" variant="primary" disabled={status === 'sending'} className="self-start">
          {status === 'sending' ? (
            <>
              <Loader2 size={16} className="animate-spin" aria-hidden="true" /> Sending
            </>
          ) : (
            <>
              Send Message <Send size={16} aria-hidden="true" />
            </>
          )}
        </MagneticButton>

        <div aria-live="polite" role="status" className="min-h-[1.5rem]">
          {status === 'success' ? (
            <p className="flex items-start gap-3 border border-ink-500 bg-ink-800 p-4 text-sm text-fg">
              <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-hi" aria-hidden="true" />
              Thanks. Your message was sent successfully.
            </p>
          ) : null}
          {status === 'unconfigured' ? (
            <p className="flex items-start gap-3 border border-dashed border-silver/50 bg-ink-800 p-4 text-sm text-sub">
              <Info size={18} className="mt-0.5 shrink-0 text-silver" aria-hidden="true" />
              <span>
                This form isn&apos;t connected to a mail service yet, so nothing was sent.{' '}
                {emailReady ? (
                  <>
                    Please email me directly at{' '}
                    <a className="text-fg underline underline-offset-4" href={emailLink.url}>
                      {emailLink.value}
                    </a>
                    .
                  </>
                ) : (
                  'Direct contact details will be added soon.'
                )}
              </span>
            </p>
          ) : null}
          {status === 'error' ? (
            <p role="alert" className="flex items-start gap-3 border border-red-400/40 bg-ink-800 p-4 text-sm text-red-200">
              <AlertCircle size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
              Something went wrong and your message wasn&apos;t sent. Please try again in a moment.
            </p>
          ) : null}
        </div>
      </div>
    </form>
  )
}

export default function Contact() {
  return (
    <section
      id="contact"
      className="grain relative scroll-mt-16 overflow-hidden bg-ink-900 pb-28 pt-28 md:pb-36 md:pt-40"
    >
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(55% 45% at 80% 20%, rgba(140,140,140,0.25), transparent 70%), radial-gradient(40% 40% at 0% 100%, rgba(80,80,80,0.3), transparent 70%)',
        }}
      />
      <div aria-hidden="true" className="grid-bg absolute inset-0 opacity-60" />

      <div className="relative z-10 mx-auto max-w-7xl px-6 md:px-10">
        <Reveal>
          <p className="eyebrow mb-6 flex items-center gap-4">
            <span className="text-silver">06</span>
            <span className="h-px w-12 bg-ink-500" />
            Contact
          </p>
        </Reveal>

        <Reveal delay={0.08}>
          <h2 className="font-display text-[clamp(2.8rem,9vw,8.5rem)] font-bold uppercase leading-[0.9] tracking-tighter">
            <span className="block text-hi">Let&apos;s build</span>
            <span className="block text-metal">something</span>
            <span className="block text-outline">great.</span>
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-14 lg:grid-cols-12 lg:gap-20">
          <Reveal className="lg:col-span-5" delay={0.1}>
            <p className="max-w-md text-lg leading-relaxed text-sub">{contact.text}</p>
            <ul className="mt-10 space-y-3">
              {contact.links.map((l) => (
                <ContactLink key={l.id} link={l} />
              ))}
            </ul>
          </Reveal>

          <Reveal className="lg:col-span-7" delay={0.15}>
            <ContactForm />
          </Reveal>
        </div>
      </div>
    </section>
  )
}
