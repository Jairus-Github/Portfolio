import { forwardRef, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowUpRight, Image as ImageIcon, Link2Off } from 'lucide-react'
import { projects } from '../data/portfolio'
import { GitHubIcon } from './ui/icons'
import Reveal from './ui/Reveal'
import SectionHeading from './ui/SectionHeading'
import TiltCard from './ui/TiltCard'

/** Large visual preview: video, screenshot, or an honest placeholder. */
function Preview({ project }) {
  return (
    <TiltCard max={5} className="w-full">
      <div className="relative">
        <div
          aria-hidden="true"
          className="absolute inset-0 translate-x-3 translate-y-3 border border-ink-500 transition-transform duration-500 group-hover:translate-x-5 group-hover:translate-y-5"
        />
        <div className="metal-border relative overflow-hidden" style={{ '--surface': '#222222' }}>
          {/* Window chrome */}
          <div className="flex items-center gap-2 border-b border-ink-500 bg-ink-800 px-4 py-3">
            <span className="h-2.5 w-2.5 rounded-full bg-ink-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-ink-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-ink-500" />
            <span className="ml-3 truncate font-mono text-[10px] uppercase tracking-[0.2em] text-mute">
              {project.title}
            </span>
          </div>

          <div className="relative aspect-[16/10] overflow-hidden bg-ink-900">
            {project.video ? (
              <video
                src={project.video}
                className="h-full w-full object-cover"
                autoPlay
                muted
                loop
                playsInline
                preload="metadata"
                aria-label={`${project.title} preview video`}
              />
            ) : project.image ? (
              <img
                src={project.image}
                alt={`Screenshot of ${project.title}`}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
            ) : (
              <div
                className="relative flex h-full w-full flex-col items-center justify-center text-center"
                style={{
                  background:
                    'radial-gradient(70% 70% at 30% 20%, #3d3d3d 0%, #1d1d1d 60%, #131313 100%)',
                }}
              >
                <div aria-hidden="true" className="grid-bg absolute inset-0" />
                <span className="relative font-display text-[clamp(5rem,12vw,9rem)] font-bold leading-none text-outline opacity-60 transition-opacity duration-500 group-hover:opacity-100">
                  {project.number}
                </span>
                <p className="relative mt-4 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-mute">
                  <ImageIcon size={14} aria-hidden="true" /> Add a screenshot or video
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </TiltCard>
  )
}

function LinkButton({ href, icon, children }) {
  if (!href) {
    return (
      <span
        aria-disabled="true"
        title="Link not added yet"
        className="inline-flex cursor-not-allowed items-center gap-2 border border-dashed border-ink-500 px-5 py-3 font-mono text-[11px] uppercase tracking-[0.18em] text-mute"
      >
        <Link2Off size={14} aria-hidden="true" /> {children} · coming soon
      </span>
    )
  }
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="group/link inline-flex items-center gap-2 border border-ink-500 px-5 py-3 font-mono text-[11px] uppercase tracking-[0.18em] text-fg transition-colors hover:border-silver hover:bg-fg hover:text-ink-900"
    >
      {icon} {children}
      <ArrowUpRight size={14} className="transition-transform group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5" aria-hidden="true" />
    </a>
  )
}

const ProjectCase = forwardRef(function ProjectCase({ project, index }, ref) {
  const flip = index % 2 === 1
  return (
    <motion.article
      ref={ref}
      layout
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="relative grid items-center gap-10 py-14 lg:grid-cols-12 lg:gap-16 lg:py-20"
      aria-labelledby={`project-${project.id}`}
    >
      <div className={`lg:col-span-7 ${flip ? 'lg:order-2' : ''}`}>
        <Preview project={project} />
      </div>

      <div className={`lg:col-span-5 ${flip ? 'lg:order-1' : ''}`}>
        <div className="flex items-baseline gap-4">
          <span className="font-display text-6xl font-bold text-outline md:text-7xl">{project.number}</span>
          <span className="eyebrow">{project.type}</span>
        </div>

        <h3 id={`project-${project.id}`} className="mt-4 font-display text-3xl font-bold leading-tight text-hi md:text-4xl">
          {project.title}
        </h3>
        <p className="mt-4 leading-relaxed text-sub">{project.description}</p>

        <ul className="mt-6 flex flex-wrap gap-2" aria-label="Technologies used">
          {project.tech.map((t) => (
            <li key={t} className="border border-ink-500 bg-ink-700 px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.15em] text-silver">
              {t}
            </li>
          ))}
        </ul>

        <div className="mt-8 grid gap-8 sm:grid-cols-2">
          <div>
            <h4 className="eyebrow mb-3 !text-silver">Main functionalities</h4>
            <ul className="space-y-2 text-sm text-sub">
              {project.features.map((f) => (
                <li key={f} className="flex gap-3">
                  <span aria-hidden="true" className="mt-2 h-px w-4 shrink-0 bg-silver/60" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="eyebrow mb-3 !text-silver">My contribution</h4>
            {project.contribution ? (
              <p className="text-sm leading-relaxed text-sub">{project.contribution}</p>
            ) : (
              <p className="text-sm italic leading-relaxed text-mute">
                Add your role in this project (project.contribution in portfolio.js).
              </p>
            )}
          </div>
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <LinkButton href={project.demo}>Live demo</LinkButton>
          <LinkButton href={project.github} icon={<GitHubIcon size={14} />}>
            GitHub
          </LinkButton>
        </div>
      </div>
    </motion.article>
  )
})

export default function Projects() {
  const [filter, setFilter] = useState('All')

  const techs = useMemo(() => {
    const set = new Set()
    projects.forEach((p) => p.tech.forEach((t) => set.add(t)))
    return ['All', ...set]
  }, [])

  const visible = filter === 'All' ? projects : projects.filter((p) => p.tech.includes(filter))

  return (
    <section
      id="projects"
      className="grain relative scroll-mt-16 overflow-hidden bg-ink-800 py-28 md:py-40"
    >
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(45% 35% at 85% 10%, rgba(130,130,130,0.2), transparent 70%), radial-gradient(40% 30% at 5% 70%, rgba(90,90,90,0.2), transparent 70%)',
        }}
      />
      <div className="relative z-10 mx-auto max-w-7xl px-6 md:px-10">
        <SectionHeading number="03" eyebrow="Featured projects" title="Selected" outline="case studies." />

        <Reveal>
          <div role="group" aria-label="Filter projects by technology" className="flex flex-wrap gap-2">
            {techs.map((t) => {
              const active = filter === t
              return (
                <button
                  key={t}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setFilter(t)}
                  className={`px-4 py-2 font-mono text-[11px] uppercase tracking-[0.18em] transition-colors ${
                    active
                      ? 'bg-fg text-ink-900'
                      : 'border border-ink-500 text-sub hover:border-silver hover:text-fg'
                  }`}
                >
                  {t}
                </button>
              )
            })}
          </div>
        </Reveal>

        <div className="mt-10 divide-y divide-ink-500/60">
          <AnimatePresence mode="popLayout">
            {visible.map((p, i) => (
              <ProjectCase key={p.id} project={p} index={i} />
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  )
}
