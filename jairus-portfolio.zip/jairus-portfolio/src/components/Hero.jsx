import { lazy, Suspense, useRef } from 'react'
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion'
import { ArrowDown, ArrowUpRight, MapPin } from 'lucide-react'
import { hero, site } from '../data/portfolio'
import MagneticButton from './ui/MagneticButton'
import RevealText from './ui/RevealText'
import RotatingText from './ui/RotatingText'

// Three.js is split into its own chunk and loaded after first paint.
const HeroOrb = lazy(() => import('./HeroOrb'))

export default function Hero() {
  const ref = useRef(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const yWatermark = useTransform(scrollYProgress, [0, 1], [0, 160])
  const yOrb = useTransform(scrollYProgress, [0, 1], [0, 90])
  const yLabels = useTransform(scrollYProgress, [0, 1], [0, -70])
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, 0])

  const line = (delay) => ({
    initial: reduce ? false : { y: '110%' },
    animate: { y: 0 },
    transition: { duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] },
  })

  return (
    <section
      id="home"
      ref={ref}
      className="grain relative flex min-h-screen items-center overflow-hidden bg-ink-900 pb-24 pt-28"
    >
      {/* Layered background */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(60% 55% at 75% 40%, rgba(120,120,120,0.28) 0%, rgba(17,17,17,0) 70%), radial-gradient(45% 50% at 10% 90%, rgba(70,70,70,0.35) 0%, rgba(17,17,17,0) 70%), linear-gradient(180deg,#191919 0%,#111111 100%)',
        }}
      />
      <div aria-hidden="true" className="grid-bg absolute inset-0 animate-grid-drift" />

      {/* Parallax monogram watermark */}
      <motion.div
        aria-hidden="true"
        style={reduce ? undefined : { y: yWatermark }}
        className="pointer-events-none absolute -bottom-10 -left-6 select-none font-display text-[clamp(12rem,32vw,30rem)] font-bold leading-none text-outline opacity-[0.07]"
      >
        {site.monogram}
      </motion.div>

      <motion.div
        style={reduce ? undefined : { opacity: fade }}
        className="relative z-10 mx-auto grid w-full max-w-7xl items-center gap-10 px-6 md:px-10 lg:grid-cols-12"
      >
        {/* Left: copy */}
        <div className="lg:col-span-7">
          <motion.p
            initial={reduce ? false : { opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="eyebrow mb-6 flex items-center gap-4 !text-sub"
          >
            <span className="h-px w-10 bg-silver/60" />
            {hero.eyebrow}
          </motion.p>

          <h1 className="font-display font-bold uppercase leading-[0.88] tracking-tighter">
            <span className="sr-only">{site.name}</span>
            <span aria-hidden="true" className="block">
              {hero.nameLines.map((text, i) => (
                <span key={text} className="block overflow-hidden pb-[0.06em]">
                  <motion.span
                    {...line(0.35 + i * 0.12)}
                    className={`block text-[clamp(3.2rem,9.2vw,8rem)] ${
                      i === 2 ? 'text-outline' : i === 1 ? 'text-metal' : 'text-hi'
                    }`}
                  >
                    {text}
                  </motion.span>
                </span>
              ))}
            </span>
          </h1>

          <div className="mt-8 font-mono text-sm uppercase tracking-[0.3em] text-silver md:text-base">
            <RevealText text={hero.title} delay={1} stagger={0.028} />
          </div>

          <motion.div
            initial={reduce ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.5 }}
          >
            <p className="mt-8 max-w-xl font-display text-2xl font-medium leading-snug text-fg md:text-3xl">
              {hero.statement}
            </p>
            <p className="mt-4 max-w-lg text-base leading-relaxed text-sub">{hero.description}</p>
            <p className="mt-5 font-mono text-xs uppercase tracking-[0.22em] text-mute">
              I am a <RotatingText words={hero.roles} className="ml-1 text-silver" />
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-4">
              <MagneticButton href="#projects" variant="primary">
                Explore My Work <ArrowUpRight size={16} />
              </MagneticButton>
              <MagneticButton href="#contact" variant="ghost">
                Get In Touch
              </MagneticButton>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 font-mono text-[11px] uppercase tracking-[0.2em] text-sub">
              <span className="flex items-center gap-2">
                <MapPin size={14} className="text-silver" /> {site.location}
              </span>
              <span className="flex items-center gap-2.5">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping2 rounded-full bg-hi" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-hi" />
                </span>
                {site.availability}
              </span>
            </div>
          </motion.div>
        </div>

        {/* Right: interactive 3D object */}
        <motion.div
          style={reduce ? undefined : { y: yOrb }}
          initial={reduce ? false : { opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="relative h-[380px] sm:h-[460px] lg:col-span-5 lg:h-[640px]"
        >
          {/* CSS glow also serves as fallback when WebGL is unavailable */}
          <div
            aria-hidden="true"
            className="absolute inset-[12%] rounded-full"
            style={{
              background:
                'radial-gradient(circle at 35% 30%, rgba(220,220,220,0.35), rgba(90,90,90,0.25) 45%, rgba(17,17,17,0) 72%)',
              filter: 'blur(6px)',
            }}
          />
          <Suspense fallback={null}>
            <HeroOrb />
          </Suspense>

          <motion.div
            aria-hidden="true"
            style={reduce ? undefined : { y: yLabels }}
            className="pointer-events-none absolute inset-0"
          >
            {hero.floatingLabels.map((label, i) => (
              <span
                key={label.text}
                className={`absolute ${label.className} ${
                  i % 2 ? 'animate-float-slow' : 'animate-float'
                } glass px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-silver`}
              >
                {label.text}
              </span>
            ))}
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <a
        href="#about"
        aria-label="Scroll to the About section"
        className="absolute bottom-8 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-3 font-mono text-[10px] uppercase tracking-[0.3em] text-mute transition-colors hover:text-fg"
      >
        Scroll
        <span className="relative block h-12 w-px overflow-hidden bg-ink-500">
          <span className="absolute inset-0 animate-scroll-cue bg-hi" />
        </span>
        <ArrowDown size={12} />
      </a>
    </section>
  )
}
