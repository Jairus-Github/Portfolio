import { forwardRef, useRef, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion, useScroll, useTransform } from 'framer-motion'
import {
  Atom,
  Box,
  Braces,
  Code,
  Coffee,
  Database,
  Eye,
  FileCode,
  GitBranch,
  GitFork,
  Hammer,
  LayoutGrid,
  Palette,
  PenTool,
  Scan,
  Server,
  Terminal,
} from 'lucide-react'
import { skillCategories, skills } from '../data/portfolio'
import SectionHeading from './ui/SectionHeading'
import TiltCard from './ui/TiltCard'

// Keys referenced by `icon` in src/data/portfolio.js
const ICONS = {
  terminal: Terminal,
  coffee: Coffee,
  braces: Braces,
  code: Code,
  palette: Palette,
  atom: Atom,
  box: Box,
  grid: LayoutGrid,
  server: Server,
  branch: GitBranch,
  fork: GitFork,
  file: FileCode,
  hammer: Hammer,
  database: Database,
  pen: PenTool,
  eye: Eye,
  scan: Scan,
}

const FILTERS = [{ id: 'all', label: 'All' }, ...skillCategories]

// forwardRef is required so AnimatePresence (popLayout) can measure exiting cards
const SkillCard = forwardRef(function SkillCard({ skill }, ref) {
  const Icon = ICONS[skill.icon] || Code
  const hasLevel = typeof skill.level === 'number'
  const category = skillCategories.find((c) => c.id === skill.category)

  return (
    <motion.li
      ref={ref}
      layout
      initial={{ opacity: 0, scale: 0.94 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.94 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
    >
      <TiltCard max={10} className="h-full">
        <div
          className="metal-border relative h-full overflow-hidden p-6 transition-transform duration-300 group-hover:-translate-y-1"
          style={{ '--surface': '#292929' }}
        >
          <div
            aria-hidden="true"
            className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-white/[0.04] blur-2xl transition-opacity duration-500 group-hover:bg-white/[0.12]"
          />
          <div className="relative flex items-start justify-between">
            <span className="flex h-12 w-12 items-center justify-center border border-ink-500 bg-ink-700 text-silver transition-all duration-300 group-hover:border-silver group-hover:bg-fg group-hover:text-ink-900">
              <Icon size={22} strokeWidth={1.5} aria-hidden="true" />
            </span>
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-mute">
              {category?.label.split(' ')[0]}
            </span>
          </div>

          <h3 className="relative mt-8 font-display text-xl font-semibold text-fg">{skill.name}</h3>

          {hasLevel ? (
            <div className="relative mt-5">
              <div className="mb-2 flex justify-between font-mono text-[10px] uppercase tracking-[0.2em] text-mute">
                <span>Proficiency</span>
                <span>{skill.level}%</span>
              </div>
              <div
                className="h-1 w-full bg-ink-500"
                role="progressbar"
                aria-valuenow={skill.level}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`${skill.name} proficiency`}
              >
                <motion.div
                  className="h-full bg-gradient-to-r from-sub to-hi"
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.level}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
                />
              </div>
            </div>
          ) : null}
        </div>
      </TiltCard>
    </motion.li>
  )
})

export default function Skills() {
  const [filter, setFilter] = useState('all')
  const ref = useRef(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const yA = useTransform(scrollYProgress, [0, 1], [-60, 100])
  const yB = useTransform(scrollYProgress, [0, 1], [80, -120])

  const visible = filter === 'all' ? skills : skills.filter((s) => s.category === filter)

  return (
    <section
      id="skills"
      ref={ref}
      className="relative scroll-mt-16 overflow-hidden bg-ink-900 py-28 md:py-40"
    >
      <div aria-hidden="true" className="grid-bg absolute inset-0 opacity-70" />
      {/* Parallax decorative geometry */}
      <motion.div
        aria-hidden="true"
        style={reduce ? undefined : { y: yA }}
        className="absolute -right-24 top-24 h-72 w-72 rotate-12 border border-ink-500/70"
      />
      <motion.div
        aria-hidden="true"
        style={reduce ? undefined : { y: yB }}
        className="absolute -left-16 bottom-24 h-48 w-48 rounded-full border border-ink-500/60"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6 md:px-10">
        <SectionHeading number="02" eyebrow="Technical skills" title="The tools I" outline="build with." />

        <div role="group" aria-label="Filter skills by category" className="mb-12 flex flex-wrap gap-3">
          {FILTERS.map((f) => {
            const active = filter === f.id
            return (
              <button
                key={f.id}
                type="button"
                aria-pressed={active}
                onClick={() => setFilter(f.id)}
                className={`relative px-5 py-2.5 font-mono text-[11px] uppercase tracking-[0.2em] transition-colors ${
                  active ? 'text-ink-900' : 'border border-ink-500 text-sub hover:border-silver hover:text-fg'
                }`}
              >
                {active ? (
                  <motion.span layoutId="skill-filter" className="absolute inset-0 bg-fg" transition={{ type: 'spring', stiffness: 400, damping: 32 }} />
                ) : null}
                <span className="relative">{f.label}</span>
              </button>
            )
          })}
        </div>

        <motion.ul layout className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <AnimatePresence mode="popLayout">
            {visible.map((skill) => (
              <SkillCard key={skill.name} skill={skill} />
            ))}
          </AnimatePresence>
        </motion.ul>
      </div>
    </section>
  )
}
