/**
 * ============================================================
 *  EDIT YOUR PORTFOLIO HERE
 *  Every piece of personal information, every skill level,
 *  every project and every timeline entry lives in this file.
 *  No component needs to be touched to update your content.
 * ============================================================
 */

/* ---------- Identity ---------- */
export const site = {
  name: 'Jairus Ulrich B. Cusi',
  shortName: 'Jairus',
  brand: 'JAIRUS.DEV',
  monogram: 'JUC',
  age: 18,
  location: 'Batangas City, Philippines',
  title: 'Aspiring Software Engineer / Web Developer',
  availability: 'Open to Opportunities',
  // Full professional introduction (used for SEO / reference).
  introduction:
    "Hello, I'm Jairus Ulrich B. Cusi, an aspiring software engineer from Batangas City, Philippines. I'm passionate about programming, software development, and exploring how technology can solve real-world problems. I enjoy transforming ideas into functional digital experiences, experimenting with different technologies, and continuously improving my technical abilities. My goal is to become a skilled software engineer capable of developing innovative, meaningful, and impactful solutions.",
}

/* ---------- Navigation (ids must match section ids) ---------- */
export const nav = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'skills', label: 'Skills' },
  { id: 'projects', label: 'Projects' },
  { id: 'experience', label: 'Experience' },
  { id: 'contact', label: 'Contact' },
]

/* ---------- Hero ---------- */
export const hero = {
  eyebrow: "HELLO, WORLD. I'M",
  nameLines: ['JAIRUS', 'ULRICH B.', 'CUSI'],
  title: 'ASPIRING SOFTWARE ENGINEER',
  statement: 'Turning Ideas Into Digital Experiences.',
  description:
    'Exploring technology, building solutions, and creating meaningful digital experiences through code.',
  // Words that rotate in the "I am a ..." line
  roles: ['Web Developer', 'Problem Solver', 'Lifelong Learner', 'Builder of Ideas'],
  // Small floating technical labels around the 3D object
  floatingLabels: [
    { text: 'React', className: 'left-[2%] top-[14%]', depth: 40 },
    { text: 'Three.js', className: 'right-[2%] top-[22%]', depth: -30 },
    { text: 'Python · OpenCV', className: 'left-[0%] bottom-[24%]', depth: -50 },
    { text: 'Java', className: 'right-[6%] bottom-[12%]', depth: 30 },
  ],
}

/* ---------- About ---------- */
export const about = {
  // Leave empty to show the monogram placeholder. Put a file in /public
  // (e.g. /public/portrait.jpg) and set photo: '/portrait.jpg'
  photo: '',
  photoAlt: 'Portrait of Jairus Ulrich B. Cusi',
  paragraphs: [
    "I'm Jairus, an aspiring software engineer with a strong interest in programming, web development, and technology. I enjoy learning how things work, solving problems, and building applications that turn ideas into reality.",
    "I'm continuously exploring new technologies and challenging myself through personal and academic projects. I believe that becoming a great developer requires curiosity, consistency, creativity, and a willingness to keep learning.",
  ],
  pullQuote:
    'My goal is to become a skilled software engineer capable of developing innovative, meaningful, and impactful solutions.',
  focus: 'Software Development',
  philosophy: 'Always learning. Always building.',
}

/* ---------- Skills ----------
 * level: set a number from 0-100 to show an animated proficiency bar.
 *        Leave it as null to hide the bar (no invented expertise levels).
 * icon:  a key from ICONS in components/Skills.jsx
 */
export const skillCategories = [
  { id: 'languages', label: 'Programming Languages' },
  { id: 'frameworks', label: 'Frameworks & Libraries' },
  { id: 'tools', label: 'Tools & Technologies' },
]

export const skills = [
  { name: 'Python', category: 'languages', icon: 'terminal', level: null },
  { name: 'Java', category: 'languages', icon: 'coffee', level: null },
  { name: 'JavaScript', category: 'languages', icon: 'braces', level: null },
  { name: 'HTML5', category: 'languages', icon: 'code', level: null },
  { name: 'CSS3', category: 'languages', icon: 'palette', level: null },

  { name: 'React', category: 'frameworks', icon: 'atom', level: null },
  { name: 'Three.js', category: 'frameworks', icon: 'box', level: null },
  { name: 'Bootstrap', category: 'frameworks', icon: 'grid', level: null },
  { name: 'Node.js', category: 'frameworks', icon: 'server', level: null },

  { name: 'Git', category: 'tools', icon: 'branch', level: null },
  { name: 'GitHub', category: 'tools', icon: 'fork', level: null },
  { name: 'Visual Studio Code', category: 'tools', icon: 'file', level: null },
  { name: 'NetBeans', category: 'tools', icon: 'hammer', level: null },
  { name: 'MySQL', category: 'tools', icon: 'database', level: null },
  { name: 'Figma', category: 'tools', icon: 'pen', level: null },
  { name: 'OpenCV', category: 'tools', icon: 'eye', level: null },
  { name: 'dlib', category: 'tools', icon: 'scan', level: null },
]

/* ---------- Projects ----------
 * image:  path to a screenshot in /public, e.g. '/projects/chemistry.png'
 * video:  path to a short preview clip, e.g. '/projects/chemistry.mp4'
 * demo / github: full URLs. Leave '' until the link exists.
 * contribution: describe what YOU built. Left empty on purpose so nothing is invented.
 * features: only list what is actually implemented.
 */
export const projects = [
  {
    id: 'chemistry',
    number: '01',
    type: 'Web · Education',
    title: 'Interactive Chemistry Learning Website',
    description:
      'An educational website designed to make chemistry more engaging through interactive learning materials, animated visual elements, and 3D molecular representations.',
    tech: ['HTML', 'CSS', 'JavaScript', 'Three.js'],
    features: [
      'Interactive learning materials',
      'Animated visual elements',
      '3D molecular representations',
    ],
    contribution: '',
    image: '',
    video: '',
    demo: '',
    github: '',
  },
  {
    id: 'anti-cheating',
    number: '02',
    type: 'Computer Vision',
    title: 'Anti-Cheating Motion Detection System',
    description:
      'A computer vision-based examination monitoring system designed to identify suspicious student movements and potential cheating behavior during examinations.',
    tech: ['Python', 'OpenCV', 'dlib'],
    features: [
      'Computer vision-based examination monitoring',
      'Identification of suspicious student movements',
      'Detection of potential cheating behavior',
    ],
    contribution: '',
    image: '',
    video: '',
    demo: '',
    github: '',
  },
  {
    id: 'student-management',
    number: '03',
    type: 'Desktop Application',
    title: 'Student Management System',
    description:
      'A desktop application designed to manage student records and simplify student information management.',
    tech: ['Java', 'NetBeans', 'JFrame'],
    features: [
      'Student record management',
      'Simplified student information handling',
      'Desktop interface built with JFrame',
    ],
    contribution: '',
    image: '',
    video: '',
    demo: '',
    github: '',
  },
]

/* ---------- Education & Development timeline ----------
 * category: education | project | training | certification | milestone | achievement
 * placeholder: true renders a dashed "add yours" entry. Set to false (and fill in
 *              the fields) once the entry is real. Nothing here is fabricated.
 */
export const timelineCategories = {
  education: { label: 'Education', icon: 'cap' },
  project: { label: 'Projects', icon: 'rocket' },
  training: { label: 'Technical Training', icon: 'wrench' },
  certification: { label: 'Certifications', icon: 'award' },
  milestone: { label: 'Learning Milestones', icon: 'flag' },
  achievement: { label: 'Achievements', icon: 'star' },
}

export const timeline = [
  {
    id: 'edu-1',
    category: 'education',
    title: 'Bachelor of Science in Information Technology',
    org: '',
    period: 'In progress',
    description: 'Currently pursuing an Information Technology degree.',
    placeholder: false,
  },
  {
    id: 'proj-1',
    category: 'project',
    title: 'Interactive Chemistry Learning Website',
    org: '',
    period: '',
    description: 'Built with HTML, CSS, JavaScript, and Three.js. See Featured Projects.',
    placeholder: false,
  },
  {
    id: 'proj-2',
    category: 'project',
    title: 'Anti-Cheating Motion Detection System',
    org: '',
    period: '',
    description: 'Built with Python, OpenCV, and dlib. See Featured Projects.',
    placeholder: false,
  },
  {
    id: 'proj-3',
    category: 'project',
    title: 'Student Management System',
    org: '',
    period: '',
    description: 'Built with Java, NetBeans, and JFrame. See Featured Projects.',
    placeholder: false,
  },
  {
    id: 'train-1',
    category: 'training',
    title: 'Add a technical training or bootcamp',
    org: 'Provider name',
    period: 'Year',
    description: 'Edit this entry in src/data/portfolio.js, or remove it.',
    placeholder: true,
  },
  {
    id: 'cert-1',
    category: 'certification',
    title: 'Add a certification',
    org: 'Issuing organization',
    period: 'Year',
    description: 'Only list certifications you have actually earned.',
    placeholder: true,
  },
  {
    id: 'mile-1',
    category: 'milestone',
    title: 'Add a personal learning milestone',
    org: '',
    period: 'Year',
    description: 'For example: the first app you shipped, a language you learned.',
    placeholder: true,
  },
  {
    id: 'ach-1',
    category: 'achievement',
    title: 'Add a relevant achievement',
    org: '',
    period: 'Year',
    description: 'Awards, competitions, recognitions, or leadership roles.',
    placeholder: true,
  },
]

/* ---------- Strengths ----------
 * span: Tailwind classes for the bento layout (must stay literal strings).
 */
export const strengths = [
  {
    title: 'Problem-Solving',
    icon: 'puzzle',
    text: 'Breaking big, messy problems into small, solvable steps.',
    gradient: 'linear-gradient(145deg,#3a3a3a 0%,#1a1a1a 100%)',
    span: 'lg:col-span-5',
  },
  {
    title: 'Continuous Learning',
    icon: 'book',
    text: 'Always picking up new tools, languages, and ways of thinking.',
    gradient: 'linear-gradient(145deg,#2b2b2b 0%,#101010 100%)',
    span: 'lg:col-span-7',
  },
  {
    title: 'Adaptability',
    icon: 'shuffle',
    text: 'Comfortable switching between web, desktop, and vision projects.',
    gradient: 'linear-gradient(160deg,#444 0%,#222 100%)',
    span: 'lg:col-span-4',
  },
  {
    title: 'Creativity',
    icon: 'sparkles',
    text: 'Turning rough ideas into interfaces and experiences people enjoy.',
    gradient: 'linear-gradient(135deg,#1c1c1c 0%,#383838 100%)',
    span: 'lg:col-span-4',
  },
  {
    title: 'Attention to Detail',
    icon: 'crosshair',
    text: 'Caring about the small things that make software feel right.',
    gradient: 'linear-gradient(200deg,#353535 0%,#141414 100%)',
    span: 'lg:col-span-4',
  },
  {
    title: 'Technical Curiosity',
    icon: 'bulb',
    text: 'Wanting to understand how things work under the hood.',
    gradient: 'linear-gradient(120deg,#262626 0%,#4a4a4a 100%)',
    span: 'lg:col-span-6',
  },
  {
    title: 'Persistence',
    icon: 'mountain',
    text: 'Sticking with a hard bug or concept until it finally clicks.',
    gradient: 'linear-gradient(150deg,#161616 0%,#333 100%)',
    span: 'lg:col-span-6',
  },
]

/* ---------- Contact ----------
 * formEndpoint: paste a form-service URL (for example a Formspree endpoint such as
 *               https://formspree.io/f/xxxxxxx). While empty, the form validates
 *               input but tells visitors it is not connected yet. It never
 *               pretends a message was sent.
 * links: set placeholder to false and replace the url once the profile is real.
 */
export const contact = {
  heading: "LET'S BUILD SOMETHING GREAT.",
  text: "I'm always interested in learning, collaborating, and exploring opportunities to create meaningful digital experiences.",
  formEndpoint: '',
  links: [
    {
      id: 'email',
      label: 'Email',
      value: 'your.email@example.com',
      url: 'mailto:your.email@example.com',
      placeholder: true,
    },
    {
      id: 'github',
      label: 'GitHub',
      value: 'github.com/your-username',
      url: 'https://github.com/your-username',
      placeholder: true,
    },
    {
      id: 'linkedin',
      label: 'LinkedIn',
      value: 'linkedin.com/in/your-profile',
      url: 'https://www.linkedin.com/in/your-profile',
      placeholder: true,
    },
    {
      id: 'other',
      label: 'Other profile',
      value: 'Add another professional link',
      url: '',
      placeholder: true,
    },
  ],
}
