import { useEffect, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion, useScroll, useSpring } from 'framer-motion'
import { site } from './data/portfolio'
import About from './components/About'
import Contact from './components/Contact'
import Footer from './components/Footer'
import Hero from './components/Hero'
import Navbar from './components/Navbar'
import Projects from './components/Projects'
import Skills from './components/Skills'
import Strengths from './components/Strengths'
import Timeline from './components/Timeline'
import CustomCursor from './components/ui/CustomCursor'

/** Short monogram intro shown once on load. */
function Intro({ onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 1100)
    return () => clearTimeout(t)
  }, [onDone])

  return (
    <motion.div
      aria-hidden="true"
      className="fixed inset-0 z-[100] flex items-center justify-center bg-ink-900"
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: 'easeInOut' }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9, letterSpacing: '0.6em' }}
        animate={{ opacity: 1, scale: 1, letterSpacing: '0.25em' }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="border border-silver/50 px-8 py-5 font-display text-3xl font-bold text-hi"
      >
        {site.monogram}
      </motion.div>
    </motion.div>
  )
}

export default function App() {
  const reduce = useReducedMotion()
  const [intro, setIntro] = useState(!reduce)
  const { scrollYProgress } = useScroll()
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30, restDelta: 0.001 })

  return (
    <>
      <a
        href="#main"
        className="sr-only z-[110] bg-fg px-4 py-2 font-mono text-xs uppercase text-ink-900 focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to content
      </a>

      <AnimatePresence>{intro ? <Intro onDone={() => setIntro(false)} /> : null}</AnimatePresence>

      <CustomCursor />
      <motion.div
        aria-hidden="true"
        style={{ scaleX: progress }}
        className="fixed inset-x-0 top-0 z-[60] h-[2px] origin-left bg-gradient-to-r from-sub to-hi"
      />

      <Navbar />
      <main id="main">
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Timeline />
        <Strengths />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
